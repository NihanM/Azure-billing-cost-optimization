from azure.cosmos import CosmosClient
from azure.storage.blob import BlobServiceClient
import json

COSMOS_ENDPOINT = "<COSMOS-URI>"
COSMOS_KEY = "<KEY>"
DATABASE = "<DATABASE_NAME>"
CONTAINER = "<CONTAINER_NAME>"

BLOB_CONN_STR = "<BLOB_CONN_STRING>"
BLOB_CONTAINER = "<BLOB_CONTAINER_NAME>"

client = CosmosClient(COSMOS_ENDPOINT, COSMOS_KEY)
container = client.get_database_client(DATABASE).get_container_client(CONTAINER)
blob_service = BlobServiceClient.from_connection_string(BLOB_CONN_STR)
blob_container = blob_service.get_container_client(BLOB_CONTAINER)

def get_billing_record(record_id, partition_key):
    try:
        return container.read_item(item=record_id, partition_key=partition_key)
    except:
        blob_client = blob_container.get_blob_client(f"{record_id}.json")
        blob_data = blob_client.download_blob().readall()
        return json.loads(blob_data)

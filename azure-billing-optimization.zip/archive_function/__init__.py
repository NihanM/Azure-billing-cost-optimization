from azure.cosmos import CosmosClient
from azure.storage.blob import BlobServiceClient
import json, datetime

COSMOS_ENDPOINT = "<COSMOS-URI>"
COSMOS_KEY = "<KEY>"
DATABASE = "<DATABASE_NAME>"
CONTAINER = "<CONTAINER_NAME>"

BLOB_CONN_STR = "<BLOB_CONN_STRING>"
BLOB_CONTAINER = "<BLOB_CONTAINER_NAME>"

client = CosmosClient(COSMOS_ENDPOINT, COSMOS_KEY)
container = client.get_database_client(DATABASE).get_container_client(CONTAINER)
blob_service = BlobServiceClient.from_connection_string(BLOB_CONN_STR)
blob_container = blob_service.get_container_client(BLOB_CONTAINER)

def archive_old_records():
    three_months_ago = (datetime.datetime.utcnow() - datetime.timedelta(days=90)).isoformat()

    query = f"SELECT * FROM c WHERE c.timestamp < '{three_months_ago}'"
    for record in container.query_items(query, enable_cross_partition_query=True):
        blob_name = f"{record['id']}.json"
        blob_container.upload_blob(blob_name, json.dumps(record), overwrite=True)
        container.delete_item(item=record, partition_key=record['partitionKey'])

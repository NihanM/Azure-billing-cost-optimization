# Azure Cost Optimization for Billing Records

## Overview
This project implements a hybrid hot/cold data storage strategy using Azure Cosmos DB and Azure Blob Storage to reduce costs for storing billing records.

## Features
- No downtime
- No API changes
- Easy to maintain
- Cost-effective

## Architecture
See `/architecture/architecture-diagram.png`

## Components
- `/archive_function`: Moves old records to cold storage
- `/read_proxy`: Reads from Cosmos DB or fallback to Blob

## Setup Instructions
1. Deploy Functions via Azure Portal or VS Code
2. Schedule Timer trigger for archival
3. Secure Blob with RBAC or SAS
